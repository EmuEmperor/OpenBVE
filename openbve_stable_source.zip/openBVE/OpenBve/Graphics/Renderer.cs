﻿using System;

namespace OpenBve {
	/// <summary>Represents the renderer.</summary>
	internal static partial class Renderer {
		
		// The bulk of the renderer is contained in the old Renderer.cs file.
		// The new renderer will be gradually implemented here.
		
	}
}
