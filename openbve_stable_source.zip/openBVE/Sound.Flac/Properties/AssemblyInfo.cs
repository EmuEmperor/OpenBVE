﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FLAC Sound Loader")]
[assembly: AssemblyDescription("Supports loading native FLAC files.")]
[assembly: AssemblyProduct("openBVE")]
[assembly: AssemblyCopyright("(Public Domain) http://trainsimframework.org/")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyVersion("0.0.0.0")]