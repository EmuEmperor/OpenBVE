﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

/* Created and released into the public domain by odakyufan
 * http://odakyufan.zxq.net/ */

[assembly: AssemblyTitle("OpenBveAts")]
[assembly: AssemblyDescription("The default ATS/ATC train plugin used by openBVE if a train does not come with its own plugin.")]
[assembly: AssemblyProduct("openBVE")]
[assembly: AssemblyCopyright("(Public Domain) http://trainsimframework.org/")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: AssemblyVersion("0.0.0.0")]