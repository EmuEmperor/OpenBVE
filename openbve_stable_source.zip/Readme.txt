﻿============================
openBVE Source Code - Readme
============================


-----
Links
-----

Official homepage:
http://trainsimframework.org/

Official discussion board:
http://openbve.freeforums.org/


----------
No license
----------

This program is placed in the public domain. This means that you can make any modifications to it you like and share your modifications with others.