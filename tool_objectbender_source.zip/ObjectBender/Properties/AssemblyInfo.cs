﻿using System.Reflection;

[assembly: AssemblyTitle("ObjectBender")]
[assembly: AssemblyProduct("ObjectBender")]
[assembly: AssemblyCopyright("(Public Domain) http://trainsimframework.org/")]
[assembly: AssemblyVersion("1.0.0.3")]
[assembly: AssemblyFileVersion("1.0.0.3")]