﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("RouteViewer")]
[assembly: AssemblyProduct("RouteViewer")]
[assembly: AssemblyCopyright("(Public Domain) http://trainsimframework.org/")]
[assembly: ComVisible(false)]
[assembly: Guid("bd68500e-8db6-4394-8fec-6adcde64c213")]
[assembly: AssemblyVersion("1.4.0.0")]
[assembly: AssemblyFileVersion("1.4.0.0")]