﻿using System.Reflection;

[assembly: AssemblyTitle("TrainEditor")]
[assembly: AssemblyProduct("TrainEditor")]
[assembly: AssemblyCopyright("(Public Domain) http://trainsimframework.org/")]
[assembly: AssemblyVersion("1.2.11.15")]
[assembly: AssemblyFileVersion("1.2.11.15")]